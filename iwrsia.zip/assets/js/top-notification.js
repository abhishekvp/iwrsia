(function($){


//var today = new Date();
//var dd = today.getDate();
//var mm = today.getMonth()+1; //January is 0!
//var yyyy = today.getFullYear();

//$('div#alt').click(

//alert("The selected participants for the workshop have been notified by email. This workshop is by invitation only. Thank you for your interest.")


//)

//if(dd<=27 && mm<=3 && yyyy==2016){
//$('div#notice').slideDown(1000)



//$('span#close').click(

//  function() {
//      $('div#notice').slideUp(1000)

//    }

//)
//}
})(jQuery);
